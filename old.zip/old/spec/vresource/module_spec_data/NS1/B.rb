class B < NS1::A
end