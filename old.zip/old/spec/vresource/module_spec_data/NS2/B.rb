class B < NS2::A
  include NS2::M
end