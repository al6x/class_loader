class ChainTest
# "ProviderB"
end