class ChainTest
# "ProviderA"
end